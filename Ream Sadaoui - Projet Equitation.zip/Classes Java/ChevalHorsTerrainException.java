public class ChevalHorsTerrainException extends Exception {
    //Constructeur
    public ChevalHorsTerrainException(String s){
        super(s);
    }

    /**
     * Override du toString
     * @return Lancement de ChevalHorsTerrainException
     */
    @Override
    public String toString() {
        return "Lancement de ChevalHorsTerrainException";
    }
}
