import java.util.ArrayList;

public class Cheval extends EtreVivant {
    public static ArrayList<Cheval>listeDeCheval = new ArrayList<Cheval>();
    private Jockey jockey;
    boolean estMonter;

    /***
     * Constructure de Cheval et ajout du cheval courant dans une liste
     * @param n le nom
     * @param a l'age
     * @param e l'energie
     */
    public Cheval(String n, int a, double e){
        super(n,a,e);
        listeDeCheval.add(this);
    }
    /***
     * Methode toString
     * @return Je suis un cheval et je cours
     */
    public String toString(){
        return "Je suis un Cheval et je cours hehe";
    }
    /***
     * Constructeur de clone
     * @param nom du nouveau cheval
     * @return un nouveau cheval de la meme race mais un nom différent
     */
     public Cheval clone(String nom){
         return new Cheval(nom,this.age,this.energie);
    }

    /***
     * Getteur
     * @return le nom du cheval
     */
    @Override
    public String getNom() {
        return super.getNom();
    }

    /**
     * Methode qui sert dans la methode monterCheval - Jockey
     * @param b boolean
     */
    public void setEstMonter(boolean b){
        estMonter = b;
    }

    /**
     * Methode qui sert a recuperer la valeur d'un cheval monté ou pas
     * @return
     */
    public boolean getEstMonter(){
        return estMonter;
    }

    /**
     * Methode pour definir si un cheval est monté ou pas (je crois qu'elle sert dans courir - Terrain)
     * @param j un jockey
     * @return true (est monté) / false (n'est pas monté)
     */
    public boolean estMonter(Jockey j){
        if (j.monterChevalTrue(j,this)){
            setEstMonter(true);
            return true;
        } else setEstMonter(false);
        return false;
    }
}
