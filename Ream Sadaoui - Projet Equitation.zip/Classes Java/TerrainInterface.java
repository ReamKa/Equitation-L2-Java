public interface TerrainInterface {
    /**
     * interface courir
     * @throws ChevalHorsTerrainException
     */
    public void courir() throws ChevalHorsTerrainException;

    /**
     * interface perdreCourse
     * @param c le cheval
     */
    public void perdreCourse(Cheval c);

    /**
     * interface gagnerCourse
     * @param c le cheval
     */
    public void gagnerCourse(Cheval c);

    /**
     * interface de positionnement des chevaux
     */
    public void aVosMarque();
}
