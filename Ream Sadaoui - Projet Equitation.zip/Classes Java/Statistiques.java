import java.util.ArrayList;

public abstract class Statistiques {
    /*abstraite : statistiques globales*/
    public abstract  void statistiquesGlobales();
    /*abstraite : position*/
    public abstract void position(ArrayList<Jockey> jockeys, Terrain terrain);
}
