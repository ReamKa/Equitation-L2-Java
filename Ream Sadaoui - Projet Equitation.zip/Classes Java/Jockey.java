import java.util.ArrayList;

public class Jockey extends EtreVivant {
    // Attributs
    private int expertise;
    protected static ArrayList<Cheval>chevaux = Cheval.listeDeCheval;
    protected static ArrayList<Jockey>listeJockey = new ArrayList<Jockey>();
    private boolean monterCheval = false;

    //Constructeur
    public Jockey(String n, int age, double energy, int ansExpertise){
        super(n,age,energy);
        expertise = ansExpertise;
        listeJockey.add(this);
    }

    /**
     * De sorte à ce que nos jockeys gagnent de l'expertise avec le temps
     */
    public void setExpertise(){
        if (age >= 18){ expertise++;}
    }

    /**
     * Pour montrer qu'un cheval est monté. Est utile pour les tests dans les autres methodes
     * @param j jockey
     * @param c cheval
     * @return true
     * */
    public boolean monterChevalTrue(Jockey j, Cheval c){
        return monterCheval = true;
    }

    /**
     * Faire monter tous les chevaux par un jockey si celui-ci a assez d'expertise. Ou n'est pas dans les pommes. Ou si le cheval n'est pas indomptable
     * @throws PlusDeJockeyQueDeChevauxException s'il y a plus de jockeys que de chevaux
     */
    public void monterCheval() throws PlusDeJockeyQueDeChevauxException, PlusDeChevauxQueDeJockeys {
        if (listeJockey.size() > chevaux.size()) {
            throw new PlusDeJockeyQueDeChevauxException("Lancement : PlusDeJockeyQueDeChevauxException");
        } else if(chevaux.size() > listeJockey.size()){
            throw new PlusDeChevauxQueDeJockeys(toString());
        } else {
            for (int i = 0; i < chevaux.size(); i++) {
                if (listeJockey.get(i).expertise < 5) {
                    System.out.println(listeJockey.get(i).nom + " n'a pas assez d'annees d'expertise. Il ne peut donc pas monter " + chevaux.get(i).getNom() +". Il ne quittera pas la ligne de depart.");
                    chevaux.get(i).setEstMonter(false);
                }else if (listeJockey.get(i).getTomberDansLesPommes()) {
                    listeJockey.get(i).tomberDansLesPommes(this);
                    System.out.println("OMG LE JOCKEY EST TOMBE DANS LES POMMES");
                } else if (chevaux.get(i) == Indomptable.Indomptable()){
                    System.out.println("IMPOSSIBLE DE LE MONTER C'EST ZORO L'INDOMPTABLE");
                }else {
                    chevaux.get(i).setEstMonter(true);
                    System.out.println(listeJockey.get(i).nom + " monte le Cheval " + chevaux.get(i).nom);
                }
            }
        }
        System.out.println();
    }

    /**
     * Si un cheval monté tombe il perd la course
     * @param j jockey
     * @param c cheval
     * @param t le terrain
     */
    public void tomberCheval(Jockey j, Cheval c,Terrain t){
        if (monterChevalTrue(j, c)) {
            t.perdreCourse(c);
        } else {
            System.out.println(c.getNom() + " n'est pas monté");
        }
    }

    /**
     * on tue un cheval s'il a perdu la course (je devrais rajouter un nombre de pertes minimal pour tuer un cheval)
     * @param c cheval
     * @param t terrain
     */
    public void tuerCheval(Cheval c,Terrain t){
        t.videCase(c.getX(),c.getY());
        c = null;
    }
}
