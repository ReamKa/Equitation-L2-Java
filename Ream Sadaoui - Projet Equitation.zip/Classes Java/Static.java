public final class Static {
    //Constructeur privé
    private Static(){};

    /*Annoncement du début*/
    public static void announcement(){
        System.out.println("MESDAMES ET MONSIEURS ! BIENVENUE A L'HIPPODROME DE SAINT CLOUD OU LES PLUS GRANDS JOCKEYS SE DEFIERONT ");
    }
    /*Annoncement de la fin*/
    public static void ending(){
        System.out.println("Et c'est comme ca qu'on cloture la soiree avec notre sublime gagnant ! N'oubliez pas qu'il y a une after-party !");
    }

    /**
     * Affichage initial du terrain
     * @param t un terrain
     */
    public static void affichageInitial(Terrain t){
        System.out.println("Affichage du terrain initial : ");
        t.aVosMarque();
        t.affiche();
    }

    /*Preparation des chevaux*/
    public static void unDeuxTrois(){
        System.out.println("A VOS MARQUES !!");
        System.out.println("PREEEEEEEET !!!");
        System.out.println("PARTEEEEEEEEEEEEEEEEEEEEEEEEEZZZZZZZZZZZZZZ\n");
    }

    /**
     * Affichage final du terrain
     * @param t un terrain
     */
    public static void affichageFinal(Terrain t){
        ending();
        t.affiche();
    }
}
