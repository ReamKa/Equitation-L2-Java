
import java.util.ArrayList;
import java.util.Scanner;

public class Spectateur extends EtreVivant {
    private boolean covid = false;
    protected double argent;
    private boolean gagnant = false;
    private boolean acheterTicket;
    public static ArrayList<Spectateur> listeDeSpectateurs = new ArrayList<Spectateur>();

    /***
     * Constructeur de spectacteur
     * @param name
     * @param age
     * @param energy
     * @param portemonnaie
     */
    public Spectateur(String name, int age, double energy, double portemonnaie) {
        super(name, age, energy);
        argent = portemonnaie;
        listeDeSpectateurs.add(this);
    }

    /***
     * Check si on peut acheter un ticket
     * @return true si personne majeur et argent > 3 euros
     */
    public void acheterTicket() {
        if (age < 18) {
            System.out.println(getNom() + " : personne mineure - interdiction d'achat sans parent");
            acheterTicket = false;
        } else if (argent < 3) {
            System.out.println(getNom() + " : vous avez moins de 3 euros, pour aller ou ??");
            acheterTicket = false;
        } else {
            System.out.println(getNom() + " : achat valide");
            acheterTicket = true;
        }
        System.out.println();
    }

    /***
     * Override de ToString
     * @return "Nous sommes des spectateurs"
     */
    public String toString() {
        return "Nous sommes des spectateurs";
    }

    /**
     * Getteur
     * @return nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Un spectateur peut chanter (meme si on est pas dans un stade de foot...)
     * @param chant une string
     * @return le chant
     */
    public String chanter(String chant) {
        return chant;
    }

    /**
     * @return la liste de spectateur
     */
    public ArrayList<Spectateur> getListeDeSpectateurs() {
        return listeDeSpectateurs;
    }

    /**
     * On parie une somme sur un cheval present sur un certain terrain. On perd 3 fois sur 4. Quand il ya un gagnant (gagnant = true)
     * personne après ne peut gagner car on met gagnant à false
     * @param t le terrain
     * @param c le cheval
     * @param argentMis la somme misée
     */
    public void parier(Terrain t, ArrayList<Cheval> c, int argentMis) {
        int aleatoire = (int) Math.random() * 2;
        if (acheterTicket == true) {
            for (int i = 0; i < listeDeSpectateurs.size() && i < c.size(); i++) {
                if(aleatoire == 1 || aleatoire == 2 || aleatoire == 3 || gagnant == true){
                    argentMis = 0;
                } else {
                    gagnant = true;
                    argentMis += 1000;
                }
            }
        } else {
            System.out.println(getNom() + " - pari interdit.\n");
        }
    }

    /**
     * On demande si on est en periode covid, si oui, il n'y a plus de spectateurs
     */
    public void covid(){
        System.out.println("Sommes nous en periode COVID ? Reponses acceptees : oui / non");
        Scanner scanner = new Scanner(System.in);
        String userInput = (scanner.nextLine()).toLowerCase();
        if (userInput.equals("oui")) {
            for (int i = 0; i < listeDeSpectateurs.size(); i++) {
                listeDeSpectateurs.set(i,null);
            }
            setCovidReponse(true);
        } else if (userInput.equals("non")){
            System.out.println("Oye ! Veuillez prendre vos places\n");
            setCovidReponse(false);
        } else {
            System.out.println("Vous n'avez pas entrer de réponse valide. On assumera donc que nous ne sommes pas en periode Covid");
            setCovidReponse(false);
        }
    }

    /**
     * On change la valeur de covid selon si on est en period covid ou pas
     * @param b un boolean
     */
    public void setCovidReponse(boolean b){
        covid = b;
    }

    /**
     * On recupere la valeur pour effectuer des tests
     * @return la valeur de covid (soit true ou false)
     */
    public boolean getCovidReponse(){
        return covid;
    }
}
