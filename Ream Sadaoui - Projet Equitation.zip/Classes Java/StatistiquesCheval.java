import java.util.ArrayList;

public class StatistiquesCheval extends Statistiques {
    ArrayList<Cheval>listeC = Cheval.listeDeCheval;
    public StatistiquesCheval(){};

    /**
     * Stats sur combien de chevaux il y a
     */
    @Override
    public void statistiquesGlobales() {
        System.out.println("Il y a " + Cheval.listeDeCheval.size() + " chevaux.");
    }

    /**
     * On renvoie la position des chevaux ainsi que par qui ils sont montés. S'il est le cheval gagnant on le dit directement (pas besoin de renvoyer sa position)
     * @param jockey
     * @param terrain
     */
    @Override
    public void  position(ArrayList<Jockey> jockey, Terrain terrain) {
        for (int i = 0; i < jockey.size(); ++i) {
                listeC.get(i).setPosition(0,i+1);
                System.out.println("Le cheval "+ listeC.get(i).getNom() + " est en position " + listeC.get(i).getX() + ", " + listeC.get(i).getY());
            }
        }
    }
