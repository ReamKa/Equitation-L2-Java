import java.util.ArrayList;

public class Indomptable extends Cheval {
    private  static String race;
    private static Indomptable purSang = null;

    /**
     * Constructeur singleton privé
     * @param n le nom
     * @param a l'age
     * @param e l'energie
     * @param race la race
     */
    private Indomptable(String n, int a, double e, String race){
        super( n,  a,  e);
        this.race = race;
    }

    /**
     * Creation d'UN SEUL cheval indomptable
     * @return un cheval purSang s'il n'existe pas, ou le purSang s'il a déjà étè crée
     */
    public static Indomptable Indomptable(){
        if(purSang == null){
            purSang = new Indomptable("Zoro",50,100,"Pur Sang");
        }
        return purSang;
    }

    /**
     * Redefinition de setEstMonter qui met setEstMonter à false automatiquement. Zoro ne peut pas etre monté
     * @param b boolean
     */
    @Override
    public void setEstMonter(boolean b) {
        super.setEstMonter(false);
    }

    /**
     * EstMonter renvoie false car il n'est pas monté par un Jockey
     * @param j un jockey
     * @return false
     */
    @Override
    public boolean estMonter(Jockey j) {
        System.out.println("IMPOSSIBLE DE LE MONTER IT IS ZORO HIMSELF");
        return false;
    }
}
