public class EtreVivant {
    /***
     * Attributs
     */
    protected String nom;
    protected int age;
    protected double energie;
    protected EtreVivant etreVivant;
    protected int x,y;
    protected  boolean boo;
    protected boolean tomberPommes;
    /***
     * Constructueur de la classe mère
     * @param nom
     * @param age
     * @param energie
     */
    public EtreVivant(String nom, int age, double energie){
        this.nom = nom;
        this.age = age;
        this.energie = energie;
        this.x = -1;
        this.y = -1;
    }

    /***
     * L'etre vivant mange quand son energie atteint 50%, ou ne mange pas et son energie baisse
     */
    public void manger(){
        if(energie <= 50){
            energie+=20;
        } else {
            energie --;
        };
    }

    /***
     * l'etre vivant boit entre 0L et 3L
     *  @return un chiffre aléatoire entre 0L et 3
     */
    public double boire(){
        return Math.round(Math.random()*4);
    }

    /***
     * Donne de l'eau à boire s'il tombe dans les pommes
     */
    public int tomberDansLesPommes(EtreVivant vivant) {
        if (boire() == 0.0) {
            vivant.boire();
            System.out.println("Quel choc emotionnel");
            return 0;
        } else {
            return 1;
        }
    }
    public void setTomberDansLesPommes(boolean tomberDansLesPommes){
        tomberPommes = tomberDansLesPommes;
    }
    public boolean getTomberDansLesPommes(){
        return tomberPommes;
    }
    /***
     * Set l'energie entre 1 et 100 si l'etre n'est pas tomber dans les pommes.
     * Sinon 0.
     */
    public void setEnergie(EtreVivant v){
        if (tomberDansLesPommes(v) == 0){
            energie = 0;
        }
        else {
            energie = Math.random()*100;
        }
    }

    /**
     * On utilisera ce boolean pour checker si un etre vivant est "libre" ou pas
     * @return true
     */
    public void setBbyMaking(boolean booboo){
        boo = booboo;
    }
    //Getter pour savoir si l'etre fait des bb ou pas
    public boolean getBbyMaking(){
        return boo;
    }
    /***
     * On fait des bebes !
     * @param nomDuBebe qui est le nouveau nom du bb
     * @return un nouvel etre vivant !
     */
    public EtreVivant faitDesBB(String nomDuBebe){
        setBbyMaking(true);
        return new EtreVivant(nomDuBebe, 0, 0);
    }

    /***
     * Getter sur l'age
     * @return age
     */
    public int getAge(){
        return age;
    }

    /***
     * Redefinition de la methode toString
     * @return le nom, age et energie courants
     */
    @Override
    public String toString() {
        return "EtreVivant : " +
                "nom = '" + nom + '\'' +
                ", age = " + age +
                " ans, energie = " + energie;
    }

    /***
     * Getter sur le nom
     * @return nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Getter sur l'energie
     * @return energie
     */
    public double getEnergie() {
        return energie;
    }

    /***
     * Initialise la position de l'etre vivant à 0
     */
    public void initialisePosition() {
        this.x = -1;
        this.y = -1;
    }

    /***
     * Met un etre vivant sur un bout de terrain
     * @param nouveauX
     * @param nouveauY
     */
    public void setPosition(int nouveauX, int nouveauY) {
        this.x = nouveauX;
        this.y = nouveauY;
    }

    /**
     * Retourne x
     * @return la position en abscisse
     */
    public int getX(){
        return x;
    }

    /**
     * Retourne y
     * @return la position en ordonnée
     */
    public int getY(){
        return y;
    }
}
