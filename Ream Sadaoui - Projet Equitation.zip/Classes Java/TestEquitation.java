import java.util.ArrayList;

public class TestEquitation {
    /***
     * @Author Hichem Erjil & Ream Sadaoui
     * @param args
     */

    public static void main (String [] args) throws ChevalHorsTerrainException, PlusDeJockeyQueDeChevauxException, PlusDeChevauxQueDeJockeys{
        //Creation des Statistiques
        StatistiquesJockeys statistiquesJockeys = new StatistiquesJockeys();
        StatistiquesCheval statistiquesCheval = new StatistiquesCheval();
        
        //Creation d'un mini terrain
        Terrain terrain = new Terrain(6,6);

        //Création des chevaux
        ArrayList<Cheval>listeDeCheval = Cheval.listeDeCheval;
        Cheval mustang = new Cheval("Mumu",3,57.9);
        Cheval bibi = mustang.clone("Bibi");
        Cheval light = new Cheval("Lili",6,7);
        Cheval delta = new Cheval("Dede",18,9);
        Indomptable pursang = Indomptable.Indomptable();

        //Creation des Spectateurs
        ArrayList<Spectateur> listeDeSpectateurs = Spectateur.listeDeSpectateurs;
        Spectateur spectateur1  = new Spectateur("Eli",14,50,2);
        Spectateur spectateur2 = new Spectateur("Kara",19,0,535);
        Spectateur spectateur3 = new Spectateur("Loul",3,50,55);
        Spectateur specteur4 = new Spectateur("Moha",67,50,50);
        Spectateur spectateur5 = new Spectateur("Rim",15,50,50);
        Spectateur spectateur6 = new Spectateur("Bg",34,50,50);

        //Creation des Jockeys
        int i = 0;
        ArrayList<Jockey> listeDeJockey = Jockey.listeJockey;
        Jockey jUn = new Jockey("J" + i, 16+i,100 - 2*i, 3+i); i ++;
        Jockey jDeux = new Jockey("J" + i, 16+i,100 - 2*i, 3+i); i ++;
        Jockey jTrois = new Jockey("J" + i, 16+i,100 - 2*i, 3+i); i ++;
        Jockey jQuatre = new Jockey("J" + i, 16+i,100 - 2*i, 3+i); i ++;
        Jockey jCinq = new Jockey("J" + i, 16+i,100 - 2*i, 3+i); i ++;

        //Annoncement des statistiques initiales
        statistiquesCheval.statistiquesGlobales();
        statistiquesJockeys.statistiquesGlobales();
        System.out.println();

        //Annoncement et positionnement des spectateurs si getCovidReponse vaut false
        Static.announcement();
        spectateur1.covid();
        if (!spectateur1.getCovidReponse()){
            terrain.positionnementDesSpectateurs();
        } else {
            System.out.println();
        }

        //Si nous sommes pas en période Covid, les spectateurs achetent des tickets, à manger et parient
        if (!spectateur1.getCovidReponse()) {
            for (int c = 0; c < listeDeSpectateurs.size();c++) {
                listeDeSpectateurs.get(c).acheterTicket();
                listeDeSpectateurs.get(c).manger();
                listeDeSpectateurs.get(c).boire();
            }
            for (int j = 0; j < listeDeCheval.size(); j++) {
                listeDeSpectateurs.get(j).parier(terrain, listeDeCheval, 10 + j);
            }
        } else {
            System.out.println("Aucun ticket achete. Paris fermes.\n");
        }

        //Montée des Jockeys sur les chevaux et affichage du terrain si tout se passe bien
        try {
            jUn.monterCheval();
            statistiquesCheval.position(Jockey.listeJockey, terrain);
            Static.affichageInitial(terrain);
        } catch (PlusDeJockeyQueDeChevauxException jd){
            System.out.println(jd.toString());
        } catch (PlusDeChevauxQueDeJockeys chevauxQueDeJockeys){
            System.out.println(chevauxQueDeJockeys.toString());
        }

        //UN DEUX TROIIIIIIS PIIIING
        Static.unDeuxTrois();

        //Les chevals courent et delta gagne si tout va bien
        try {
            terrain.courir();
            terrain.gagnerCourse(delta);
        } catch (ChevalHorsTerrainException ch){
            System.out.println("Le cheval a dépassé les bornes");
        }

        //Des chants s'élèvent dans les rangs
        if (!spectateur1.getCovidReponse()) {
            System.out.println(spectateur1.chanter("Spectateur 1 : DELTA DELTA DELTA DELTA"));
            System.out.println(spectateur2.chanter("Spectateur 2: C'EST QUOI CE FOUTU BORDEL COMMENT CA J'AI MISE SUR UN CHEVAL QUI NE COURT PAS. MON ARGENT ! RENDEZ LE MOI !!!"));
            System.out.println(spectateur3.chanter("Spectateur 3: Euh cherie c'est une course de dromadaires la ou c'est moi ...\n"));
        } else {
            System.out.println("*Bruits de criquets*");
        }

        //Mumu va faire des bebes avec Bibi vu qu'ils s'ennuient. On les retire du terrain. Bibi tombe dans les pommes la pauvre
        System.out.println("Mais que voyons-nous a notre gauche !! La creation d'un Bibi Jr. ");
        mustang.faitDesBB("Bibi Jr.");
        bibi.boire();
        mustang.tomberDansLesPommes(bibi);

        //Affichage intermediaire apres que Light ai perdu la course et Delta l'ai gagné. Clairement Zoro ne comprends toujours pas ..
        jTrois.tomberCheval(jTrois,light,terrain);
        terrain.perdreCourse(light);
        terrain.gagnerCourse(delta);
        terrain.affiche();

        //Affichage final après la mort de Light
        listeDeJockey.get(3).tuerCheval(light,terrain);
        Static.affichageFinal(terrain);
    }
}

