public class PlusDeJockeyQueDeChevauxException extends Exception {
    /**
     * Constructeur
     * @param s une string
     */
    public PlusDeJockeyQueDeChevauxException(String s){
        super(s);
    }

    /**
     * toString
     * @return Lancement de PlusDeJockeyQueDeChevauxException
     */
    public String toString(){
        return "Lancement de PlusDeJockeyQueDeChevauxException";
    }
}
