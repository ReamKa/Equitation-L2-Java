import java.util.ArrayList;

public class StatistiquesJockeys extends Statistiques {
    public StatistiquesJockeys(){};

    @Override
    /**
     * On renvoie combien il ya de jockeys
     */
    public void statistiquesGlobales() {
        System.out.println("Il y a " + Jockey.listeJockey.size() + " jockeys.");
    }

    /**
     * On renvoie la position du jockey
     * @param jockey
     * @param terrain
     */
    @Override
    public void position(ArrayList<Jockey> jockey, Terrain terrain) {
        for (Jockey value : jockey) {
            System.out.println("Le jockey " + value.getNom() + " est en position " + value.getX() + ", " + value.getY());
        }
    }
}
