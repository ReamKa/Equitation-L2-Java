public class PlusDeChevauxQueDeJockeys extends Exception {
    /**
     * Constructeur
     * @param s une string
     */
    public PlusDeChevauxQueDeJockeys(String s){
        super(s);
    }

    /**
     * ToString
     * @return Lancement de PlusDeChevauxQueDeJockeys Exception
     */
    public String toString(){
        return "Lancement de PlusDeChevauxQueDeJockeys Exception";
    }
}
