import java.util.ArrayList;

public final class Terrain implements TerrainInterface {
    public static final int NBLIGNESMAX = 20;
    public static final int NBCOLONNESMAX = 20;
    private static final int NBCARAFFICHES = 5;
    public final int nbLignes;
    public final int nbColonnes ;
    private final EtreVivant[][] terrain;
    protected boolean boo = false;
    ArrayList<Cheval> liste = Cheval.listeDeCheval;
    ArrayList<Spectateur> listeSpec = Spectateur.listeDeSpectateurs;
    ArrayList<Jockey> listeJockey = Jockey.listeJockey;

    public Terrain() {
        this(20, 20);
    }
    public Terrain(int var1, int var2) {
        if (var1 > 20) {
            this.nbLignes = 20;
        } else if (var1 <= 0) {
            this.nbLignes = 1;
        } else {
            this.nbLignes = var1;
        }

        if (var2 > 20) {
            this.nbColonnes = 20;
        } else if (var2 <= 0) {
            this.nbColonnes = 1;
        } else {
            this.nbColonnes = var2;
        }

        this.terrain = new EtreVivant[this.nbLignes][this.nbColonnes];
    }

    /***
     * Le cheval ne peut pas courir aleatoirement car cela fait disparaitre 2 chevaux qui se retouvent
     * sur la meme case. Levée d'exception si monsieur se balade en dehors du terrain
     * monsieur ne court pas s'il fait des babies
     * si le cheval n'est pas monter il ne peut pas courir
     *  l'energie descend
     */
    public void courir() throws ChevalHorsTerrainException {
                    int y = 1, x = 0;
                    for (int i = 0; i < liste.size(); i++) {
                        if (liste.get(i).age < 0 || liste.get(i).getTomberDansLesPommes()){
                            System.out.println("Le cheval " + liste.get(i).nom + " ne peut pas courir car soit il est fatigue ou mineur !");
                        } else if (y > terrain.length || x > terrain.length) {
                            throw new ChevalHorsTerrainException("Lancement de ChevalHorsTerrainException");
                        } else if (liste.get(i).getBbyMaking() == true){
                            System.out.println("Le cheval " + liste.get(i).getNom() + " fait chingchingbangbang. Il ne peut courir");
                            videCase(liste.get(i).x,liste.get(i).y);
                        }else if (getGagnerCourse() == true) {
                            continue;
                        } else if (!liste.get(i).getEstMonter()) {
                            if (liste.get(i) == Indomptable.Indomptable()) {
                                System.out.println("ZORO IS A FREE SPIRIT. Il ne comprends pas le language des humains, il bouge pas ...\n");
                            } else {
                                System.out.println(liste.get(i).nom + " n'est pas monte, il peut pas courir !\n");
                                videCase(liste.get(i).x, liste.get(i).y);
                            }
                        }else if (listeJockey.get(i).monterChevalTrue(listeJockey.get(i),liste.get(i)) == true) {
                            videCase(liste.get(i).x, liste.get(i).y);
                            setCase(x, y, liste.get(i));
                            liste.get(i).setPosition(x,y);
                            liste.get(i).energie--;
                            x++;
                            y++;
                        } else {
                            System.out.println("Le cheval ne peut pas courir");
                }
            }
        }

    /***
     * Le cheval perd la course en le placant quelque part loin de la limite du terrain (entre 0 et terrain.length -1)
     * @param c un cheval
     */
    public void perdreCourse(Cheval c){
        if (c.getAge() < 18 || c.getEnergie() == 0){
            videCase(c.x, c.y);
            setCase(1 + (int)(Math.random()* terrain.length - 1),1 + (int)(Math.random()* terrain.length-1),c);
            setPerdreCourse(c);
        } else {
            setCase(c.x + 1,c.y + 1,c);
            setPerdreCourse(c);
        }
    }

    /**
     * Setteur à mettre quand un cheval a gagné
     * @param c un cheval
     */
    public boolean setGagnerCourse(Cheval c){
        return boo = true;
    }
    public boolean setPerdreCourse(Cheval c) { return boo = false;}

    /**
     * Setter pouvoir faire des tests dans les methodes
     * @return false ou true
     */
    public boolean getGagnerCourse(){
        return boo;
    }
    /***
     * On positionne le cheval à la limite du terrain : c'est notre gagnant
     * @param c qui est le cheval gagnant
     */
    public void gagnerCourse(Cheval c){
        setGagnerCourse(c);
        videCase(c.x,c.y);
        setCase(terrain.length-1,terrain.length - 1,c);
     }

    /***
     * On met tous les chevaux sur la ligne de depart.
     * i+1 car les chevaux ne doivent pas courir sur les spectateurs ...
     */
    public void aVosMarque(){
        for (int i = 0; i < liste.size();i++){
            setCase(0,i+1, (EtreVivant) liste.get(i));
        }
    }

    /**
     * On met les spectateurs sur le cote
     * On check s'il n'y a pas de covid
     * Au lieu d'une exception on check que i est inferieur a la liste et au terrain pour eviter les debordements
     */
    public void positionnementDesSpectateurs() {
        int j = terrain.length - 1;
            for (int i = 0; i < listeSpec.size() && i <= terrain.length; i++) {
                if (listeSpec.get(i) == null) {
                    System.out.println("Il n'y a pas de spectateurs a cause du COVID");
                    break;
                } else {
                    setCase(j, 0, listeSpec.get(i));
                    j--;
                }
            }
        }

        public EtreVivant getCase(int var1, int var2) {
        return this.sontValides(var1, var2) ? this.terrain[var1][var2] : null;
    }
        public EtreVivant videCase(int var1, int var2) {
        if (this.sontValides(var1, var2) && this.terrain[var1][var2] != null) {
            EtreVivant var3 = this.terrain[var1][var2];
            var3.initialisePosition();
            this.terrain[var1][var2] = null;
            return var3;
        } else {
            return null;
        }
    }

        public boolean setCase(int var1, int var2, EtreVivant var3) {
        if (this.sontValides(var1, var2)) {
            if (this.terrain[var1][var2] != null) {
                this.terrain[var1][var2].initialisePosition();
            }

            this.terrain[var1][var2] = var3;
            var3.setPosition(var1, var2);
            return true;
        } else {
            return false;
        }
    }

        public boolean caseEstVide(int var1, int var2) {
        if (this.sontValides(var1, var2)) {
            return this.terrain[var1][var2] == null;
        } else {
            return true;
        }
    }

        public boolean sontValides(int var1, int var2) {
        return var1 >= 0 && var1 < this.nbLignes && var2 >= 0 && var2 < this.nbColonnes;
    }

        public void affiche() {
        String var1 = "";
        String var2 = ":";
        String var3 = "";

        int var4;
        for(var4 = 0; var4 < 5; ++var4) {
            var3 = var3 + "-";
        }

        for(var4 = 0; var4 < this.nbColonnes; ++var4) {
            var2 = var2 + var3 + ":";
        }

        var2 = var2 + "\n";
        var1 = var2;

        for(var4 = 0; var4 < this.nbLignes; ++var4) {
            for(int var5 = 0; var5 < this.nbColonnes; ++var5) {
                if (this.terrain[var4][var5] == null) {
                    var1 = var1 + "|" + String.format("%-5s", " ");
                } else {
                    var1 = var1 + "|" + this.premiersCar(this.terrain[var4][var5].nom);
                }
            }

            var1 = var1 + "|\n" + var2;
        }
        System.out.println(var1);
    }

        public String toString() {
        int var1 = 0;

        for(int var2 = 0; var2 < this.nbLignes; ++var2) {
            for(int var3 = 0; var3 < this.nbColonnes; ++var3) {
                if (this.terrain[var2][var3] != null) {
                    ++var1;
                }
            }
        }

        String var4 = "Terrain de " + this.nbLignes + "x" + this.nbColonnes + " cases: ";
        if (var1 == 0) {
            var4 = var4 + "toutes les cases sont libres.";
        } else if (var1 == 1) {
            var4 = var4 + "il y a une case occupée.";
        } else {
            var4 = var4 + "il y a " + var1 + " cases occupées.";
        }

        return var4;
    }

        private String premiersCar(String var1) {
        String var2 = String.format("%-5s", var1);
        return var2.substring(0, 5);
    }
    }
